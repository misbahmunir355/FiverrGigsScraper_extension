
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractGigs") {
    setTimeout(() => {
      const cards = document.querySelectorAll('.gig-card-layout');
      const gigs = [...cards].map(card => {
        let name = '';
        const nameEl = card.querySelector('a.text-bold span');
        if (nameEl) name = nameEl.innerText.trim().replace(/,/g, '');

        let title = '';
        const titleEl = card.querySelector('p[role="heading"]');
        if (titleEl) title = titleEl.innerText.trim().replace(/,/g, '');

        const rating = card.querySelector('.rating-score')?.innerText.trim().replace(/,/g, '') || '';
        const reviews = card.querySelector('.rating-count-number')?.innerText.trim().replace(/,/g, '') || '';

        let level = '';
        const levelEl = Array.from(card.querySelectorAll('p')).find(p =>
          /(level|top rated|new seller|choice|vetted pro)/i.test(p.innerText)
        );
        if (levelEl) level = levelEl.innerText.trim().replace(/,/g, '');

        let price = '';
        const priceEl = Array.from(card.querySelectorAll('span')).find(span =>
          /PKR/.test(span.innerText)
        );
        if (priceEl) price = priceEl.innerText.replace(/\u00a0/, ' ').trim().replace(/,/g, '');

        return {
          Name: name,
          Title: title,
          Rating: rating,
          Reviews: reviews,
          Level: level,
          StartingPrice: price
        };
      });

      sendResponse({ gigs });
    }, 1000);
    return true;
  }
});

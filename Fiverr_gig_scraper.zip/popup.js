
document.addEventListener('DOMContentLoaded', function () {
  const btn = document.getElementById('downloadCsv');
  btn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const tab = tabs[0];
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      }, () => {
        chrome.tabs.sendMessage(tab.id, { action: "extractGigs" }, function (response) {
          if (!response || !response.gigs || response.gigs.length === 0) {
            alert("No data found.");
            return;
          }
          const data = response.gigs;
          const csv = [Object.keys(data[0]).join(",")].concat(data.map(row => Object.values(row).join(","))).join("\n");
          const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
          const link = document.createElement("a");
          link.href = URL.createObjectURL(blob);
          link.download = "fiverr_gigs.csv";
          link.click();
        });
      });
    });
  });
});
